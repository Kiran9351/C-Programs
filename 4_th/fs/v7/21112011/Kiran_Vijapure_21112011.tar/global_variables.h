
/*

Declaring global variables.

*/

long long disksize;
int blocksize;
long long no_of_blocks;
int no_of_fmd_blocks;
int no_of_fmds;
int no_of_flag_bytes;
int no_of_files;
int *arr = NULL;
int arr_size;
unsigned char *bmap;
int count_bits;
int fs;
int counts;
int progress;
int total_blocks_to_write;
int total_blocks_to_delete;
int per;
