
/*

Including .h files.

*/

#include"helper.h"
#include"write.h"
#include"read.h"
#include"get_file_info.h"
#include"file_names.h"
#include"delete_file.h"
